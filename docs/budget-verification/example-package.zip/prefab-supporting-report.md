# Model 300 supporting screening report

SAVED EXAMPLE ONLY — not my property.

Preliminary supplied-placement screening; source observations and candidate rules remain unreviewed. Intended use supplied: Garden suite. The planning comparisons use a garden-suite scenario; City or professional review must establish whether that scenario applies. Exact values and complete identifiers are retained in the accompanying technical evidence.

## Example answers

Demo-supplied answers: street context, intended use, relationship, requested response. These illustrate an example enquiry; they are not facts about your property. Other answers retain their stated defaults or user attribution.

## Overall account

No concerns identified in the included checks; missing information and unsupported conditions remain unresolved.

Mapped estimates and supplied measurements have different bases. None establishes legal feasibility.

## Boundary planning assumptions

Street-adjoining edge selection is incomplete. Candidate front and street-side alternatives remain unresolved; complete the known street marks or keep the context unknown before relying on boundary comparisons. Individual candidate distances remain in the technical evidence.

## Additional scouting checks

Distance from the main building: not assessed. Main-home identification or usable building geometry is unresolved. Source: City of Victoria, Zoning Bylaw 2018, No. 18-072, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018) (Part 3.1(28)(h), PDF p28; approximate roofline-to-nominal comparison only; legal endpoints unresolved).

Front boundary distance: not assessed. Front-line classification or waterfront applicability is unresolved. Source: City of Victoria, Zoning Bylaw 2018, No. 18-072, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018) (Part 4.1(4)(a), PDF p31, buildings with less than three dwelling units; Part 2.1 Setback, PDF p19).

Located behind the main building: not assessed. The main home, rear boundary or waterfront status is unresolved. Source: City of Victoria, Zoning Bylaw 2018, No. 18-072, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018) (Part 3.1(28)(a), PDF p27; Part 2.1 Rear Yard, PDF p19; approximate parallel rear-face construction only).

Share of the rear yard: not assessed. The main home or rear-yard area is unresolved. Source: City of Victoria, Zoning Bylaw 2018, No. 18-072, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018) (Part 3.1(28)(i), PDF p28; nominal footprint divided by approximate rear-yard area, not lot area).

Height: not assessed. Installed height, grade and the measurement datum are unresolved. Source: City of Victoria, Zoning Bylaw 2018, No. 18-072, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018) (Part 3.1(28)(e), PDF p27; Part 2.1 Height, PDF p17; Average Grade, PDF p12).

Floor area: not assessed. Regulatory floor area and its inclusions are unresolved. Source: City of Victoria, Zoning Bylaw 2018, No. 18-072, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018) (Part 3.1(28)(d), PDF p27; Part 2.1 Floor Area, PDF p16).

## Price & timing

Model price is not total project cost. Installation duration is not the full project timeline. Confirm a current quote and site-specific schedule with the provider.

Starting at CAD 187,000. Configuration: Public Model 300 one-bedroom page; upgrades not fixed. Region: not specified. Model starting price, not total project cost. Upgrades are listed separately; their prices and a fixed configuration are not supplied. The page lists North America delivery; regional pricing is not stated. Inclusions: Full bathroom and complete kitchen described on the model page. Additional costs/exclusions: Permitting; Foundations; Site services; Shipping; Installation. Tax treatment: unknown. Manufacturer wording: “Starting at $187,000 CAD. On-site prep including permitting, foundations, site services, shipping, and install at additional cost”. aux box · Model 300 · Starting price; Layout & Specs &gt; Materials, Upgrades, Site Prep, Delivery + Installation · captured 2026-10-06 · unreviewed; source revision unknown; updated date unknown. Source: [https://www.auxbox.ca/model-300](https://www.auxbox.ca/model-300)

Contract to delivery: roughly 12–18 weeks · provider-wide. Configuration: not specified. Region: not specified. Provider-wide estimate; not a Model 300 or property-specific schedule. Does not separately quantify factory production or delivery transit time. Clock starts: Purchase contract. Prerequisites/dependencies: Model choice; Production schedule; Permitting requirements. Manufacturer wording: “Roughly 12-18 weeks from purchase contract to delivery, depending on the model you choose, our production schedule and the permitting requirements. Smaller models can have shorter lead times. Larger models can have longer lead times.”. aux box · provider-wide statement · How long does it take? · captured 2026-10-06 · unreviewed; source revision unknown; updated date unknown. Source: [https://www.auxbox.ca/faqs](https://www.auxbox.ca/faqs)

On-site installation: 1 day · provider-wide. Configuration: not specified. Region: not specified. Provider-wide delivery/placement-day claim; not the full project timeline or a Model 300 installation guarantee. Foundation preparation is a separate process step; no standalone transit duration is supplied. Clock starts: not specified. Prerequisites/dependencies: Site qualification; Permits where required; Design confirmation; Foundation and services preparation; Crane access. Manufacturer wording: “Your aux box is delivered by truck and placed on-site by crane, all in one day”. aux box · provider-wide statement · Installed in one day; How it works steps 1–6 · captured 2026-10-06 · unreviewed; source revision unknown; updated date unknown. Source: [https://www.auxbox.ca/how-it-works](https://www.auxbox.ca/how-it-works)

Production lead time: unknown in the captured catalogue sources.

Delivery transit: unknown in the captured catalogue sources.

## Project cost draft

Budget scope: Whole project. Cost coverage is incomplete; a complete scenario range is unavailable.

Priced-components subtotal: CAD 189,500.25 or more; upper amount unknown.

Price source: aux box, Model 300 price claim, captured 2026-10-06, unreviewed. [https://www.auxbox.ca/model-300](https://www.auxbox.ca/model-300)

Still unpriced or unresolved: Upgrades, Foundation and site work, Service connections, Professional work, Fees, Tax, Contingency.

Tax basis is unstated on priced work; specify whether tax is included or separately allowed.

At least one priced line has no finite upper amount. A starting price cannot bound the project.

Allowances are user assumptions. Source claims and user-entered quote facts remain unreviewed; tax treatment and scope must be stated for a complete scenario.

## Model

Prepared independently with ShovelReady; no affiliation with or contact to aux box.

Design: aux box Model 300; public page captured 2026-09-25; unreviewed; manufacturer revision unknown. Nominal exterior 10 ft × 30 ft (3.05 m × 9.14 m). Advertised exterior height 10 ft 6 in; regulatory installed height and datum unknown. Source: [https://www.auxbox.ca/model-300](https://www.auxbox.ca/model-300).

Provider service/installation: Provider says delivered anywhere in North America; Victoria project service and site feasibility unconfirmed. Provider says crane placement; permitting, foundation, site services, shipping and installation are separate site work/costs.

## Property

Example property / saved data: City of Victoria Parcel 87; captured 2026-09-26; unreviewed. Parcel source: [https://maps.victoria.ca/server/rest/services/OpenData/OpenData\_Land/MapServer/11/query](https://maps.victoria.ca/server/rest/services/OpenData/OpenData_Land/MapServer/11) (Parcel 87). Roofline source: [https://maps.victoria.ca/server/rest/services/OpenData/OpenData\_Land/MapServer/1/query](https://maps.victoria.ca/server/rest/services/OpenData/OpenData_Land/MapServer/1) (Mapped roofline 69542). Contains information licensed under the Open Government Licence – City of Victoria: [https://opendata.victoria.ca/pages/open-data-licence](https://opendata.victoria.ca/pages/open-data-licence). Full source record links are in the technical evidence export. This is not the sender's property or a verified address.

Use: Garden suite. Timing: unknown. Budget, if shared: Around CAD 250,000; scope to discuss.

Access and crane questions/known facts: unknown. Utility/services questions/known facts: unknown.

## Placement

Illustrative placement on the saved example Victoria parcel 87: nominal rectangle 3.05 m × 9.14 m (width catalogue nominal; depth catalogue nominal), rotation -9.52°. The rectangle lies inside the mapped parcel. No overlap with the captured rooflines was observed; other obstructions remain unknown. Observed parcel boundary distance 2.08 m. Captured 2026-09-26; unreviewed; approximate captured geometry only.

Foundation scenario allowance: 0.3 m planning assumption (default or edited). This allowance is used only in the labelled preliminary height estimate; installed height remains unverified.

## Approximate setbacks

Side, rear and street-side boundary comparison: not assessed. This subset excludes front distance, rear-yard location/share and height/area; those results are listed separately. Source: City of Victoria, Zoning Bylaw 2018, No. 18-072, captured 2026-10-06, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018)

## Conditional zoning

Intended use: Garden suite. Screening use: garden suite (demo-supplied scenario, not a property fact). Foundation attachment: attached to a permanent foundation scenario (default assumption, unconfirmed). Main-building type: not supplied (user answer, unverified). Existing garden suites: 0 (default assumption, unconfirmed). Waterfront status: no (default assumption, unconfirmed). Main outline: Outline 1, assumed from the largest mapped outline, not verified as the main house. Main-home identification and legal boundaries remain unverified. Intended use supplied: Garden suite. The planning comparisons use a garden-suite scenario; City or professional review must establish whether that scenario applies.

Candidate Victoria garden-suite comparison for this supplied placement: 2 checks meet under stated assumptions; no concerns identified in the supplied-facts comparisons; 13 need information; 0 outside scope. Candidate source/currentness and site facts remain unreviewed; no approval or complete bylaw review.

Conflicting PDF consolidation labels; exact effective interval is unresolved. Independent legal interpretation and parcel applicability review are pending.

Legal lot: not assessed: a required measurement or property fact is missing. The source-selected parcel does not establish legal lot identity; title or survey records and the property contact can confirm it.

Current zoning: not assessed: a required measurement or property fact is missing. The property contact and City staff need to confirm the relevant property fact and its applicability.

Applicable zoning bylaw: not assessed: a required measurement or property fact is missing. The property contact and City staff need to confirm the relevant property fact and its applicability.

Proposed use: meets under the supplied facts. This records the screening scenario; it does not confirm the intended project or property fact.

Foundation attachment: meets under the supplied facts. This records the screening scenario; it does not confirm the intended project or property fact.

Existing main building type: not assessed: a required measurement or property fact is missing. The property contact and City staff need to confirm the relevant property fact and its applicability. This records the screening scenario; it does not confirm the intended project or property fact.

Main building selection: not assessed: a required measurement or property fact is missing. The mapped main home is an assumption; the property contact can confirm its identity on the plan. This records the screening scenario; it does not confirm the intended project or property fact.

Garden suite count: not assessed: a required measurement or property fact is missing. Existing suites and the lot’s eligibility need confirmation by the property contact and City staff.

Parcel edge 1 role: not assessed: a required measurement or property fact is missing. The property contact and City staff need to confirm the relevant property fact and its applicability.

Parcel edge 2 role: not assessed: a required measurement or property fact is missing. The property contact and City staff need to confirm the relevant property fact and its applicability.

Parcel edge 3 role: not assessed: a required measurement or property fact is missing. The property contact and City staff need to confirm the relevant property fact and its applicability.

Parcel edge 4 role: not assessed: a required measurement or property fact is missing. The property contact and City staff need to confirm the relevant property fact and its applicability.

Flanking street line presence: not assessed: a required measurement or property fact is missing. This comparison needs compatible wall-to-legal-line measurements and review of projections and waterfront conditions; a surveyor and City staff can establish these.

Separation from main building: not assessed: a required measurement or property fact is missing. The mapped roof gap is reported separately. Legal wall/projection endpoints and their separation need a survey or approved plans and City review.

Garden suite floor area: not assessed: a required measurement or property fact is missing. The manufacturer’s plans need a compatible floor-area calculation, including the relevant levels and inclusions; the buffered footprint estimate is reported separately.

Candidate source: City of Victoria, Zoning Bylaw 2018, No. 18-072, captured 2026-10-06, candidate; [https://www.victoria.ca/media/file/zoning-bylaw-2018](https://www.victoria.ca/media/file/zoning-bylaw-2018). Clause references: Part 4.1(1)(h),(1.1)(b), PDF p30; Part 2.2 Residential and Garden Suite, PDF pp21-22; Part 3.1(28)(b), PDF p27; Part 3.1(28)(f), PDF pp27-28; Part 2.1 Setback and Side Lot Line, PDF p19; Part 3.1(28)(g), PDF pp27-28; Part 2.1 Flanking Street Lot Line and Setback, PDF pp15-16 and p19; Part 3.1(28)(h), PDF p28; Part 3.1(28)(d), PDF p27; Part 2.1 Floor Area, PDF p16.

## Still to confirm

Questions: Please confirm the current controlled Model 300 drawing/revision, installed envelope and height datum; roof projections and site clearances; local delivery/crane access, foundation and utility requirements; and what site information you need before discussing this property.

Legal lot lines, building walls and roles, other obstructions, zoning and setbacks, installed height and datum, current controlled provider dimensions, access and services remain unresolved.

Planning feasibility remains unconfirmed. Manufacturer drawings, property confirmation and City or professional review are separate next steps.

Full technical evidence: [prefab-technical-evidence.json](prefab-technical-evidence.json).

Approximate drawing: [PNG](prefab-placement.png) · [PDF](prefab-placement.pdf). These are not surveys or approved site plans.
