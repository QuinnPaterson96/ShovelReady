# Model 300 feasibility enquiry — 419 Cecelia Rd, Victoria, BC

SAVED EXAMPLE ONLY — not my property.

Please advise what information is needed for initial suitability advice.

## Example answers

Demo-supplied answers: street context, intended use, relationship, requested response. These illustrate an example enquiry; they are not facts about your property. Other answers retain their stated defaults or user attribution.

## Project

I’m exploring aux box Model 300 at 419 Cecelia Rd, Victoria, BC. I would use it for Garden suite.

My spending preference is Around CAD 250,000; scope to discuss.

## Cost scope for discussion

Cost scope: Whole project. Priced-components subtotal: CAD 189,500.25 or more; upper amount unknown. Based on aux box published starting price (captured 2026-10-06, unreviewed; [https://www.auxbox.ca/model-300](https://www.auxbox.ca/model-300)) and Delivery and lift owner allowance (CAD 2,500.25). Unpriced or unresolved: Upgrades, Foundation and site work, Service connections, Professional work, Fees, Tax, Contingency. Installed total unavailable; please help establish the missing scope.

Builder/provider: For Model 300, which current configuration, currency and dated price apply, and what upgrades, delivery/lift and tax are included or excluded?

Builder/provider: Which access/crane, foundation and utility facts would let you or a local contractor scope installation, and who coordinates that work?

Builder/provider: Who will confirm professional-work, permit-fee and tax scope, including any applicable waiver or credit?

## Questions for aux box

1. Can you share current dimensioned plans with their date/version, overhangs, interior floor area, height measurement reference and foundation requirements?

2. Do you service this locality?

3. What is the current lead time, when does it start, and what decisions, permits and site preparation must be complete before booking or delivery?

## Planning questions to resolve separately

Intended use supplied: Garden suite. The planning comparisons use a garden-suite scenario; City or professional review must establish whether that scenario applies.

The property contact needs to confirm the main home, existing suites and waterfront context. City staff or a qualified local professional needs to check the applicable rules, legal measurement basis and any permit or title conditions. Please advise what product information you can provide to support that review.

## Site information

The preliminary rectangle is 3.05 m × 9.14 m using published nominal dimensions. It excludes unconfirmed overhangs and installation space.

## Placement sketch

An approximate proposed placement sketch is included below; it is not a survey or approved site plan.

Thank you.

## Approximate proposed placement

![Approximate proposed placement](prefab-placement.png)
