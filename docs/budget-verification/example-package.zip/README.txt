Start with prefab-enquiry.md for the unsent provider message.
Review your-preparation-checklist.txt for the sender’s next actions.
Read prefab-supporting-report.md for the detailed findings and evidence links.
Complete source identifiers, exact values and inputs are in prefab-technical-evidence.json.
The placement PNG and PDF are approximate discussion drawings. Keep the PNG beside the Markdown enquiry so its image link works.
Nothing in this package has been sent. Review the message, sources and any drawing before sharing.
